return {
  name = "lua-bot",
  version = "1.0.0",
  description = "bla bla bla",
  dependencies = {
    "luvit/luvit" -- here you write all the dependencies, in this case, luvit only
  },
}
