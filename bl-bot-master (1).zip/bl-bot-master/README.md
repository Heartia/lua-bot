# Black Lodge Bot by Radioactium, Blackbat, and Hollosou
